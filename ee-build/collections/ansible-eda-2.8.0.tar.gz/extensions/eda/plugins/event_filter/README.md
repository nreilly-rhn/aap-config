
# EDA Event Filters

Event filters are plugins that filter events once they have been received.
Examples of these plugins are filters that remove unnecessary fields from events,
or change dashes to underscores in key names.
