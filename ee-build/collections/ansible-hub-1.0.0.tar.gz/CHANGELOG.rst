=========================
ansible.hub Release Notes
=========================

.. contents:: Topics

v1.0.0
======

Release Summary
---------------

This is the major release of the ``ansible.hub`` collection.
